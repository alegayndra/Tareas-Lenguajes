# import scanner as scanner
# import obten_token as token

# A00822649 | Alberto García Viegas
# A01634310 | Diego Estrada Talamantes
import parser as parser

# token.obten_token()
# scanner.scanner()

parser.parser()
